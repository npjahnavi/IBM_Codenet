#include<stdio.h>

int main(void) 
{

	int x, y, a, b, c, d;
	
	scanf ("%d %d" ,&x ,&y);
	if (x > y){
	x = a;
	y = b;
	} else {
	x = b;
	y = a;
}
	while (d != b){
	d=1;
	if (a % d == 0 && b % d == 0) {

	c = d;
	}
	d = d+1;
	} 

	printf("%d \n" ,c);

	return 0;
}
	