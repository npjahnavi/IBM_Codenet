#include<iostream>
using namespace std;
int c,d;main(){cin>>c>>d;cout<<__gcd(c,d)<<endl;return 0;}