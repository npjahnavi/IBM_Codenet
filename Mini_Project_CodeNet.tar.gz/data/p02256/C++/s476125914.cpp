#include <iostream>
#include <queue>
#include <stack>
#include <cstdio>
#include <vector>
#include <sstream>

using namespace std;

const int N_MAX = 1000000;

int main(){
  int x, y;
  cin >> x;
  cin >> y;
  int residue = -1;
  int p = -1;
  /*
  while(residue != 0){
    residue = max(x, y)%min(x, y);
    if(residue==0) break;
    if(x>y) x = residue;
    else y = residue;
  }*/
//  residue = 2;
//  cout << p;
  return -1;
}

