#include <iostream>
#include <algorithm>
using namespace std;
int main()
{
	long a,b;
	cin >> a >> b;
	cout << __gcd(a,b) << endl;
	return 0;
}
