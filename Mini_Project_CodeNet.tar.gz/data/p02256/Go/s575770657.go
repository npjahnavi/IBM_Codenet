package main

import (
	"fmt"
)

func gcd(a, b int) int {
	if b == 0 {
		return a
	}
	return gcd(b, a%b)
}

func main() {
	x := 0
	y := 0
	fmt.Scan(&x, &y)
	fmt.Println(gcd(x, y))
}

