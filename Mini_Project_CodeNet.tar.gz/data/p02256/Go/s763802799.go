package main

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
)

func f(x, y int) int {
	if y == 0 {
		return x
	}
	if x >= y {
		m := x % y
		return f(y, m)
	}
	m := y % x
	return f(x, m)
}

func main() {
	sc := bufio.NewScanner(os.Stdin)
	sc.Split(bufio.ScanWords)

	sc.Scan()
	x, err := strconv.Atoi(sc.Text())
	if err != nil {
		panic(err)
	}

	sc.Scan()
	y, err := strconv.Atoi(sc.Text())
	if err != nil {
		panic(err)
	}

	a := f(x, y)
	fmt.Println(a)
}

