package main

import (
    "bufio"
    "fmt"
    "os"
    "strconv"
)

var sc = bufio.NewScanner(os.Stdin)

func readNextInt() int{
  sc.Scan()
  n,_ := strconv.Atoi(sc.Text())
  return n
}

func gcd(a int, b int) int {
  if b > a {
    tmp := a
    a = b
    b = tmp
  }

  for b > 0 {
    r := a%b
    a = b
    b = r
  }

  return a
}

func main() {
  sc.Split(bufio.ScanWords)
  a := readNextInt()
  b := readNextInt()

  output := gcd(a,b)
  fmt.Println(strconv.Itoa(output))
}
