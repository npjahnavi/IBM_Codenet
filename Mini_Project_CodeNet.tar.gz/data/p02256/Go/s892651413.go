/*
Greatest Common Divisor
ALDS1_1_b
最大公約数を求めるプログラム
ユークリッド互除法を使う
*/
package main

import "fmt"

func gojo(x, y int) int {
	if x < y {
		x, y = y, x
	}

	amari := x % y
	if amari == 0 {
		return y
	}

	return gojo(amari, y)
}
func main() {
	var x, y int

	fmt.Scanf("%d %d", &x, &y)
	fmt.Println(gojo(x, y))
}
