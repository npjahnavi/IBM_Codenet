package main

import (
	"fmt"
	"bufio"
	"strconv"
	"os"
)

// assume that x >= y
func gcd(x, y int) int {
	if y == 0 {
		return x
	}
	return gcd(y, x%y)
}

func main() {
	sc := bufio.NewScanner(os.Stdin)
	sc.Split(bufio.ScanWords)

	x, err := nextInt(sc)
	if err != nil {
		panic(err)
	}

	y, err := nextInt(sc)
	if err != nil {
		panic(err)
	}

	fmt.Println(gcd(x, y))
}

func nextText(sc *bufio.Scanner) string {
	sc.Scan()
	return sc.Text()
}

func nextInt(sc *bufio.Scanner) (int, error) {
	return strconv.Atoi(nextText(sc))
}
