package main

import "fmt"

func main() {
	var x, y int
	fmt.Scan(&x, &y)
	for  {
		if x < y {
			x, y = y, x
		}
		x, y = y, x%y
		if y <=0 {
			break
		}
	}
	fmt.Println(x)
}

