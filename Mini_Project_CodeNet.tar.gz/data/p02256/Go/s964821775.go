// 最大公約数
package main
import (
	"fmt"
	"strconv"
	"bufio"
	"os"
)

var sc = bufio.NewScanner(os.Stdin)
var out = bufio.NewWriter(os.Stdout)

func main(){
	sc.Split(bufio.ScanWords)
	defer out.Flush()

	x, y := nextInt(), nextInt()
	ans := gcd(x, y)
	fmt.Fprintln(out, ans)
}

func gcd(x, y int) int{
	if x<y{
		return gcd(y, x)
	}
	for y>0{
		r:=x%y
		x, y = y, r
	}
	return x
}

func next()string{
	sc.Scan()
	return sc.Text()
}

func nextInt()int{
	a, _ := strconv.Atoi(next())
	return a
}

