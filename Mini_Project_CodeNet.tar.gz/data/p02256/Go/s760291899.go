package main

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
)

var sc *bufio.Scanner

func nextString() string {
	sc.Scan()
	i := sc.Text()
	return i
}

func nextInt() int {
	sc.Scan()
	i, _ := strconv.Atoi(sc.Text())
	return i
}

func gcd(x, y int) (r int) {
	if x < y {
		x, y = y, x
	}
	if y == 0 {
		r = x
	} else {
		r = gcd(y, x%y)
	}
	return r
}

func main() {
	sc = bufio.NewScanner(os.Stdin)
	sc.Split(bufio.ScanWords)
	x, y := nextInt(), nextInt()
	fmt.Println(gcd(x, y))
}

