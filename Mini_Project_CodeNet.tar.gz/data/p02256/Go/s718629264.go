package main

import "fmt"

func main() {
	var a, b int

	fmt.Scan(&a, &b)

	if b > a {
		a, b = b, a
	}

	for {
		if a%b == 0 {
			break
		}
		a, b = b, a%b
	}
	fmt.Println(b)
}

