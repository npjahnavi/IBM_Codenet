package main

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
)

func main() {
	sc := bufio.NewScanner(os.Stdin)
	sc.Split(bufio.ScanWords)
	vs := nextInts(2, sc)
	var res int
	if vs[0] < vs[1] {
		res = gcd(vs[0], vs[1])
	} else {
		res = gcd(vs[1], vs[0])
	}
	fmt.Println(res)
}

func gcd(x int, y int) int {
	a, b := x, y
	for a != 0 {
		a, b = b%a, a
	}
	return b
}

func nextInt(sc *bufio.Scanner) int {
	sc.Scan()
	v, err := strconv.Atoi(sc.Text())
	if err != nil {
		panic(err)
	}
	return v
}

func nextInts(num int, sc *bufio.Scanner) []int {
	vs := make([]int, num)
	for i := 0; i < num; i++ {
		vs[i] = nextInt(sc)
	}
	return vs
}

