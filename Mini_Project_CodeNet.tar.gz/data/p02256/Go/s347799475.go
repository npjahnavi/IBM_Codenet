package main

import (
	"fmt"
	"math"
)

func GCD(a, b int) int {
	if(b == 0) {
		return a
	} else {
		return GCD(b, a%b)
	}
}

func main(){
	var a, b int
	var ans int
	fmt.Scanf("%d%d", &a, &b)
	a = int(math.Abs(float64(a)))
	b = int(math.Abs(float64(b)))
	ans = GCD(a,b)
	fmt.Printf("%d\n", ans)
}

