package main

import  "fmt"

func min(x, y int) int{
    if x < y {
        return x
    } else {
        return y
    }
}

func abs(x, y int) int{
    if x < y {
        return y-x;
    } else {
        return x-y;
    }
}

func gcd(x, y int) int{
    for{
        if x == y {
            return x
        }
        z := abs(x, y)
        x = min(x, y)
        y = z
    }
}

func main(){
    var x, y int
    fmt.Scanln(&x, &y)
    fmt.Println(gcd(x,y))
}
