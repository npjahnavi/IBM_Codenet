package main

import (
	"fmt"
	"math"
)

func main() {
	var n int
	fmt.Scan(&n)
	a := make([]int, n)

	for i := range a {
		fmt.Scan(&a[i])
	}

	var m int
	for _, e := range a {
		m = max(m, e)
	}

	isNonPrimes := make([]bool, m+1)
	isNonPrimes[1] = true
	for b := 1; b <= int(math.Sqrt(float64(m))); b++ {
		if !isNonPrimes[b] {
			for k := 2; b*k <= m; k++ {
				isNonPrimes[b*k] = true
			}
		}
	}

	var c int
	for _, e := range a {
		if !isNonPrimes[e] {
			c++
		}
	}

	fmt.Println(c)
}

func max(a, b int) int {
	if a < b {
		return b
	}
	return a
}

