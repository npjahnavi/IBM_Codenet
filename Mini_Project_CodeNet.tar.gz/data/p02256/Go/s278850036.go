package main

import "fmt"

// a > b
func gcd(a, b int) int {
	if b == 0 {
		return a
	}
	return gcd(b, a % b)
}

func main() {
	var a, b int
	fmt.Scan(&a, &b)
	if a > b {
		fmt.Println(gcd(a, b))
	} else {
		fmt.Println(gcd(b, a))
	}
}

