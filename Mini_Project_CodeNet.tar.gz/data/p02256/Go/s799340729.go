package main

import "fmt"

func main() {
	var x, y int
	fmt.Scan(&x, &y)

	if x < y {
		x, y = y, x
	}

	for x%y != 0 {
		x, y = y, x%y
	}

	fmt.Println(y)
}