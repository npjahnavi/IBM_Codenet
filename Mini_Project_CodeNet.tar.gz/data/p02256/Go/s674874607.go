package main

import (
	"fmt"
	"math"
)

func main() {
	var x, y, m, n, d int
	fmt.Scanf("%d %d", &x, &y)
	m = int(math.Max(float64(x), float64(y)))
	n = int(math.Min(float64(x), float64(y)))

	for ; n != 0; {
		d = m % n //あまり
		m = n //m <- n
		n = d // n <- あまり
	}
	fmt.Printf("%d\n", m)
}

