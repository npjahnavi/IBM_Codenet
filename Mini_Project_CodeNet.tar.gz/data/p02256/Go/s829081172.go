package main

import "fmt"

func main() {
	var num1, num2 int
	fmt.Scan(&num1, &num2)
	fmt.Println(gcd(num1, num2))
}


func gcd(a, b int) int {
	if b > a {
		tmp := b
		b = a
		a = tmp
	}
	if remainder := a % b; remainder == 0 {
		return b
	} else {
		return gcd(b, remainder)
	}
}

