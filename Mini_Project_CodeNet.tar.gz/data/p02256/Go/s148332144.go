package main

import (
	"fmt"
)

func main() {
	var a, b int
	fmt.Scan(&a, &b)

	fmt.Println(gcd(a, b))
}

func gcd(a, b int) int {
	if a%b == 0 {
		return b
	}

	if a >= b {
		return gcd(b, a%b)
	}

	return 0
}

