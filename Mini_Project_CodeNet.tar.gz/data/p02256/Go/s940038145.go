package main

import (
	"fmt"
)

func f(n, m uint) uint {
	for m > 0 {
		t := n
		n = m
		m = t % m
	}

	return n
}

func main() {
	var n, m uint

	fmt.Scanf("%d %d", &n, &m)

	if m < n {
		fmt.Println(f(n, m))
	} else {
		fmt.Println(f(m, n))
	}
}

