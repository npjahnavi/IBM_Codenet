package main

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
)

func gcd(x, y int) {
	if x == 0 || y == 0 {
		fmt.Println(0)
		return
	} else if x == 1 || y == 1 {
		fmt.Println(1)
		return
	} else if x > y && y%x == 0 {
		fmt.Println(y)
		return
	} else if y > x && x%y == 0 {
		fmt.Println(x)
		return
	} else {
		if x > y {
			gcd(y, x%y)
		} else {
			gcd(x, x%y)
		}
	}
}

func main() {
	sc := bufio.NewScanner(os.Stdin)
	sc.Split(bufio.ScanWords)

	sc.Scan()
	x, err := strconv.Atoi(sc.Text())
	if err != nil {
		panic(err)
	}

	sc.Scan()
	y, err := strconv.Atoi(sc.Text())
	if err != nil {
		panic(err)
	}

	gcd(x, y)
}

