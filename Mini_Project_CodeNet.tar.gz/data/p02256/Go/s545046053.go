package main

import (
    "fmt"
    "math"
)

func min(int a, b) int{
    if a < b {
        return a
    } else {
        return b
    }
}

func main(){
    var x, y int
    fmt.Scanln(&x, &y)
    for ; x==y; {
        z := math.Abs(x-y)
        x = min(x, y)
        y = z
    }
}
