package main

import (
	"fmt"
)

func main(){
	var x, y int
	fmt.Scan(&x, &y)
	if x < y{
		x, y = y, x
	}
	for{
		if x == 0{
			fmt.Println(y)
			break
		} else if y == 0{
			fmt.Println(x)
			break
		}
		x, y = y, x%y
	}
}
