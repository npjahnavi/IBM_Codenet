package main

import "fmt"

func getGCD(x, y int) int {
	if x < y {
		x, y = y, x
	}
	if y == 0 {
		return x
	} else {
		return getGCD(y, x%y)
	}
}

func main() {
	var x, y int
	fmt.Scan(&x, &y)
	fmt.Println(getGCD(x, y))
}
