package main

import (
    "fmt"
)

func min(a, b int) int{
    if a < b {
        return a
    } else {
        return b
    }
}

func abs(a, b int) int{
    if a < b {
        return b-a;
    } else {
        return a-b;
    }
}

func main(){
    var x, y int
    fmt.Scanln(&x, &y)
    for ; x==y; {
        z := abs(x, y)
        x = min(x, y)
        y = z
    }
}
