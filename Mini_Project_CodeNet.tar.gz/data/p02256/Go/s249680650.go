package main

import "fmt"

func gcd(a, b int) int {
	if a%b == 0 { // b != 0の時、a%b == 0ならば、aとbの最大公約数はbである
		return b
	}
	// この時点でaはbで割り切れない
	// ヒントより：整数a,bについて、a>=bならばxとyの最大公約数はbとa%bの最大公約数に等しい
	// 以下のコードでは例えb>aであっても、次の呼び出しでaとbが入れ替わるのでaとbの大小関係をチェックしなくてよい
	return gcd(b, a%b)
}

func main() {
	var a, b int
	fmt.Scan(&a, &b)
	fmt.Println(gcd(a, b))
}

